
import React from 'react';
import { UserState } from '../types';

interface HeaderProps {
  user: UserState;
  onReset: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onReset }) => {
  const xpForNextLevel = user.level * 200;
  const progressPercent = (user.xp / xpForNextLevel) * 100;

  return (
    <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 p-4 shadow-xl">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={onReset}>
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <i className="fas fa-terminal text-white text-xl"></i>
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">Algoritmolândia</h1>
            <p className="text-xs text-slate-400 font-medium">Aprendiz de Programador</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden sm:flex flex-col items-end gap-1">
            <div className="flex items-center gap-2 text-sm">
              <span className="text-slate-400">Nível {user.level}</span>
              <span className="text-yellow-500 font-bold">{user.xp} / {xpForNextLevel} XP</span>
            </div>
            <div className="w-48 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-indigo-500 transition-all duration-500 ease-out"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 rounded-full border border-slate-700">
            <i className="fas fa-user-circle text-indigo-400 text-lg"></i>
            <span className="text-sm font-semibold">{user.name}</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
