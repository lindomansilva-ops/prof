
import React from 'react';
import { World, UserState, Phase } from '../types';

interface WorldMapProps {
  worlds: World[];
  user: UserState;
  onSelectPhase: (phase: Phase) => void;
}

const WorldMap: React.FC<WorldMapProps> = ({ worlds, user, onSelectPhase }) => {
  return (
    <div className="p-6 space-y-12 max-w-4xl mx-auto">
      {worlds.map((world, worldIdx) => {
        const isWorldUnlocked = world.id === 'world-1' || user.unlockedWorldId === world.id;
        
        return (
          <div key={world.id} className={`space-y-6 ${!isWorldUnlocked ? 'opacity-50' : ''}`}>
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl ${isWorldUnlocked ? 'bg-indigo-600 shadow-lg shadow-indigo-500/20' : 'bg-slate-800'}`}>
                <i className={`fas ${world.id === 'world-1' ? 'fa-globe-americas' : 'fa-lock'}`}></i>
              </div>
              <div>
                <h2 className="text-2xl font-bold">{world.title}</h2>
                <p className="text-slate-400 text-sm">{world.description}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 ml-2">
              {world.phases.map((phase, phaseIdx) => {
                // Phase is unlocked if it's the first one of an unlocked world, 
                // or if the previous phase in the same world is completed
                const isFirstPhaseOfUnlockedWorld = isWorldUnlocked && phaseIdx === 0;
                const prevPhase = phaseIdx > 0 ? world.phases[phaseIdx - 1] : null;
                const isPhaseUnlocked = isFirstPhaseOfUnlockedWorld || (prevPhase && user.completedPhaseIds.includes(prevPhase.id));
                const isCompleted = user.completedPhaseIds.includes(phase.id);

                return (
                  <button
                    key={phase.id}
                    disabled={!isPhaseUnlocked}
                    onClick={() => onSelectPhase(phase)}
                    className={`relative group flex items-center gap-4 p-4 rounded-xl border transition-all ${
                      isPhaseUnlocked 
                        ? 'bg-slate-800/50 border-slate-700 hover:border-indigo-500 hover:bg-slate-800 cursor-pointer text-left' 
                        : 'bg-slate-900 border-slate-800 cursor-not-allowed text-left'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                      isCompleted ? 'bg-green-500/20 text-green-500' : isPhaseUnlocked ? 'bg-indigo-500/20 text-indigo-400' : 'bg-slate-800 text-slate-600'
                    }`}>
                      {isCompleted ? <i className="fas fa-check"></i> : <i className="fas fa-play"></i>}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center mb-0.5">
                        <h3 className={`font-bold truncate ${isPhaseUnlocked ? 'text-slate-100' : 'text-slate-600'}`}>
                          {phase.title}
                        </h3>
                        {!isPhaseUnlocked && <i className="fas fa-lock text-xs text-slate-600"></i>}
                      </div>
                      <p className={`text-xs truncate ${isPhaseUnlocked ? 'text-slate-400' : 'text-slate-700'}`}>
                        {phase.concept}
                      </p>
                    </div>

                    {isPhaseUnlocked && !isCompleted && (
                      <div className="absolute right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <i className="fas fa-chevron-right text-indigo-400"></i>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default WorldMap;
