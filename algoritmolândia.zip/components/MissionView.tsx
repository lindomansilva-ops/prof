
import React, { useState, useEffect } from 'react';
import { Mission, Phase, AIResponse } from '../types';
import { geminiService } from '../services/geminiService';

interface MissionViewProps {
  phase: Phase;
  mission: Mission;
  onSuccess: (xp: number) => void;
  onBack: () => void;
}

const MissionView: React.FC<MissionViewProps> = ({ phase, mission, onSuccess, onBack }) => {
  const [code, setCode] = useState(mission.baseCode);
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<AIResponse | null>(null);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    const fetchExplanation = async () => {
      setLoading(true);
      const text = await geminiService.explainConcept(phase.title, 'Iniciante');
      setExplanation(text);
      setLoading(false);
    };
    fetchExplanation();
  }, [phase.title]);

  const handleTest = async () => {
    setLoading(true);
    setFeedback(null);
    const result = await geminiService.evaluateCode(code, mission.objective);
    setFeedback(result);
    setLoading(false);
    if (result.isCorrect) {
      setIsSuccess(true);
    }
  };

  const handleHint = async () => {
    setLoading(true);
    const hint = await geminiService.getHint(code, mission.objective);
    setFeedback({ type: 'hint', content: hint });
    setLoading(false);
  };

  const handleFinish = () => {
    onSuccess(mission.xpReward);
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-80px)] overflow-hidden">
      {/* Sidebar: Info & Concept */}
      <div className="w-full lg:w-96 p-6 bg-slate-900 overflow-y-auto border-r border-slate-800 space-y-6 shrink-0">
        <button onClick={onBack} className="text-slate-400 hover:text-white flex items-center gap-2 mb-4">
          <i className="fas fa-arrow-left"></i> Voltar ao Mapa
        </button>

        <div className="space-y-4">
          <div className="inline-block px-3 py-1 bg-indigo-500/20 text-indigo-400 text-xs font-bold rounded-full uppercase tracking-wider">
            Conceito da Fase
          </div>
          <h2 className="text-2xl font-bold text-white">{phase.title}</h2>
          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 italic text-slate-300 text-sm">
             {loading && !explanation ? 'Buscando sabedoria da IA...' : explanation}
          </div>
        </div>

        <div className="space-y-4">
          <div className="inline-block px-3 py-1 bg-yellow-500/20 text-yellow-400 text-xs font-bold rounded-full uppercase tracking-wider">
            Objetivo da Missão
          </div>
          <h3 className="text-xl font-bold text-slate-100">{mission.title}</h3>
          <p className="text-slate-400 text-sm leading-relaxed">{mission.objective}</p>
        </div>

        <div className="pt-4">
          <div className="p-4 bg-blue-600/10 border border-blue-500/20 rounded-xl flex gap-3">
            <i className="fas fa-info-circle text-blue-400 mt-1"></i>
            <div>
              <p className="text-xs font-bold text-blue-400 uppercase mb-1">Dica de recompensa</p>
              <p className="text-xs text-blue-200">Complete esta missão para ganhar {mission.xpReward} XP e avançar na sua jornada!</p>
            </div>
          </div>
        </div>
      </div>

      {/* Editor & Feedback */}
      <div className="flex-1 flex flex-col bg-slate-950 relative">
        <div className="flex-1 flex flex-col">
          <div className="bg-slate-900 border-b border-slate-800 px-6 py-2 flex justify-between items-center">
            <span className="text-xs font-mono text-slate-500 uppercase tracking-widest">VisualG v3.0 (Simulado)</span>
            <div className="flex gap-2">
              <button 
                onClick={handleHint}
                disabled={loading}
                className="px-3 py-1 text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors"
              >
                <i className="fas fa-lightbulb mr-2"></i> Pedir Ajuda
              </button>
            </div>
          </div>
          
          <div className="relative flex-1 group">
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full h-full p-6 bg-transparent text-indigo-300 code-font text-lg outline-none resize-none spellcheck-false"
              spellCheck={false}
              autoFocus
            />
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex justify-end gap-3">
          {isSuccess ? (
            <button
              onClick={handleFinish}
              className="px-8 py-3 bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl shadow-lg shadow-green-900/20 transition-all flex items-center gap-3 animate-bounce"
            >
              Próximo Desafio <i className="fas fa-arrow-right"></i>
            </button>
          ) : (
            <button
              onClick={handleTest}
              disabled={loading}
              className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-900/20 transition-all flex items-center gap-3"
            >
              {loading ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-play"></i>}
              Testar Algoritmo
            </button>
          )}
        </div>

        {/* AI Tutor Overlay */}
        {feedback && (
          <div className={`absolute bottom-24 right-6 left-6 p-6 rounded-2xl border-2 shadow-2xl transition-all animate-in slide-in-from-bottom-4 duration-300 ${
            feedback.isCorrect 
              ? 'bg-green-900/90 border-green-500 text-green-50' 
              : feedback.type === 'hint' ? 'bg-indigo-900/90 border-indigo-500 text-indigo-50' : 'bg-slate-800 border-slate-700 text-slate-100'
          }`}>
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center shrink-0">
                 <i className={`fas ${feedback.isCorrect ? 'fa-award text-green-400' : 'fa-robot text-indigo-400'} text-2xl`}></i>
              </div>
              <div>
                <h4 className="font-bold mb-1">{feedback.isCorrect ? 'Parabéns!' : 'O Tutor diz:'}</h4>
                <p className="text-sm leading-relaxed">{feedback.content}</p>
                {!feedback.isCorrect && (
                   <button onClick={() => setFeedback(null)} className="mt-3 text-xs font-bold uppercase tracking-widest hover:underline opacity-60">Entendi</button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MissionView;
