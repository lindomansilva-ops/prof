
import { GoogleGenAI, Type } from "@google/genai";
import { AIResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const geminiService = {
  async explainConcept(conceptName: string, level: string): Promise<string> {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Explica o seguinte conceito de programação para um iniciante, usando VisualG e exemplos simples, como se fosse um jogo de aventura: 
      CONCEITO: ${conceptName}
      NÍVEL DO ALUNO: ${level}
      Responda em português de forma encorajadora e curta.`,
    });
    return response.text || "Não consegui explicar o conceito agora. Tente novamente!";
  },

  async evaluateCode(code: string, missionObjective: string): Promise<AIResponse> {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Você é um professor de lógica de programação em VisualG. Avalie este algoritmo escrito por um iniciante baseado no objetivo da missão.
      MISSÃO: ${missionObjective}
      CÓDIGO:
      ${code}

      Regras de avaliação:
      1. Verifique se a estrutura (Algoritmo, var, inicio, fimalgoritmo) está correta.
      2. Verifique se a lógica resolve o problema proposto.
      3. Forneça feedback construtivo.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isCorrect: { type: Type.BOOLEAN },
            content: { type: Type.STRING, description: "Feedback detalhado do professor." }
          },
          required: ["isCorrect", "content"]
        }
      }
    });

    try {
      const result = JSON.parse(response.text || "{}");
      return {
        type: 'evaluation',
        content: result.content,
        isCorrect: result.isCorrect
      };
    } catch (e) {
      return { type: 'evaluation', content: "Erro ao processar avaliação. Tente novamente!", isCorrect: false };
    }
  },

  async getHint(code: string, missionObjective: string): Promise<string> {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `O aluno está travado nesta missão de VisualG.
      MISSÃO: ${missionObjective}
      CÓDIGO ATUAL:
      ${code}
      
      Dê uma dica sutil sem dar a resposta completa. Use uma linguagem de mestre de RPG ou tutor gentil.`,
    });
    return response.text || "Pense na estrutura básica... você consegue!";
  }
};
